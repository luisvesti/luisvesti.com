//****************************************
//Bibliotheken

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>
#include <unistd.h>
#include <time.h>

//****************************************
//Programm Infos

const char programVersion[] = "v2.4";
const char programAuthor[] = "luve";

/*
Name: LGT Drinkomat (Simulation)
Author: Luis Vesti
Abteilung: ISAP
Datum: 21.11.2023
*/

//****************************************
//Variablen

int stock[1][2];
int stockRequestX = 0;
int stockRequestY = 0;
int intInput = 0;
float price = 0;
float cashInput = 0;
int cashInputInt = 0;
float twintCode = 0;
float productPrice = 0;
char ch;
int i = 0;
int error = 0;
int stockRequest = 0;
int l = 0;

//****************************************
//Funktionsprototyping

int title();
int invalidInput();
int productOptions();
int paymentOptions();
int paymentCash();
int paymentCard();
int paymentTwint();
int productOutput();
int stockError();
int stockWarning();
void restock();
void fontWhite();
void fontBlue();
void fontGreen();
void fontRed();
void fontGrey();

//****************************************
//Funktionen

    void fontWhite() //Färbt die Schrift weiss **********
    {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    }

    void fontBlue() //Färbt die Schrift blau **********
    {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE);
    }

    void fontGreen() //Färbt die Schrift grün **********
    {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN);
    }

    void fontRed() //Färbt die Schrift Rot **********
    {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED);
    }

    void fontGrey() //Färbt die Schrif Grün **********
    {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, FOREGROUND_INTENSITY);
    }

    void restock() //Gibt beim start des Programmes an, wie gross der Lagerbestand der Produkte ist **********
    {
        if (l == 0)
        {
        stock[0][0] = 1;
        stock[0][1] = 10;
        stock[0][2] = 10;
        stock[1][0] = 10;
        stock[1][1] = 10;
        stock[1][2] = 10;
        l = 1;
        }
    }

    int title() //Erstellt den Titel des Programms ***********
    {
        system("cls");
        fontBlue();
        printf("LGT Drinkomat");
        fontGrey();
        printf(" || ");
        fontBlue();
        printf("%s", programVersion);
        fontGrey();
        printf(" || ");
        fontBlue();
        printf("%s", programAuthor);
        fontWhite();
        printf("\n\n");
        stockWarning();
        return 0;
    }

    int invalidInput() //Zeigt eine Fehlermeldung für invalide Eingaben an **********
    {
        error = 1;
        title();
        fontRed();
        printf("Invalide Eingabe erkannt!");
        sleep(3);
        error = 0;
    }

    int stockError() //Zeigt eine Fehlermeldung für ausverkaufte Produkte an **********
    {
        error = 1;
        title();
        fontRed();
        printf("Dieses Produkt ist ausverkauft!");
        sleep(3);
        error = 0;
    }

    int stockWarning() //Zeigt einee Warnung für ausverkaufte Produkte an **********
    {
        if (stock[0][0] == 0) {fontRed(); printf("RedBull ist ausverkauft!\n\n");}
        if (stock[0][1] == 0) {fontRed(); printf("CocaCola ist ausverkauft!\n\n");}
        if (stock[0][2] == 0) {fontRed(); printf("Focus Water ist ausverkauft!\n\n");}
        if (stock[1][0] == 0) {fontRed(); printf("M&Ms ist ausverkauft!\n\n");}
        if (stock[1][1] == 0) {fontRed(); printf("Zweifel Chips ist ausverkauft!\n\n");}
        if (stock[1][2] == 0) {fontRed(); printf("Snickers ist ausverkauft!\n\n");}
        fontWhite();
        return 0;
    }


    int productOptions() //Zeigt die Auswahl der Getränke an **********
    {
        title();
        printf("Bitte waehlen Sie ihr Produkt:\n");
        printf("[ 1 ] (CHF 2.90) Red Bull\n");
        printf("[ 2 ] (CHF 2.60) Coca Cola\n");
        printf("[ 3 ] (CHF 2.60) Focus Water\n");
        printf("[ 4 ] (CHF 3.10) M&Ms\n");
        printf("[ 5 ] (CHF 3.50) Zweifel Chips\n");
        printf("[ 6 ] (CHF 3.30) Snickers\n");
        intInput = 0;
        scanf("%d", &intInput);

        switch (intInput)
        {
        case 1:
            {title();
            printf("Produkt: Red Bull\n");
            price = 2.90;
            stockRequestY = 0;
            stockRequestX = 0;
            break;}
        case 2:
            {title();
            printf("Produkt: Coca Cola\n");
            price = 2.60;
            stockRequestY = 0;
            stockRequestX = 1;
            break;}
        case 3:
            {title();
            printf("Produkt: Focus Water\n");
            price = 2.60;
            stockRequestY = 0;
            stockRequestX = 2;
            break;}
        case 4:
            {title();
            printf("Produkt: M&Ms\n");
            price = 3.10;
            stockRequestY = 1;
            stockRequestX = 0;
            break;}
        case 5:
            {title();
            printf("Produkt: Zweifel Chips\n");
            price = 3.50;
            stockRequestY = 1;
            stockRequestX = 1;
            break;}
        case 6:
            {title();
            printf("Produkt: Snickers\n");
            price = 3.30;
            stockRequestY = 1;
            stockRequestX = 2;
            break;}
        default:
            {invalidInput();}
        }

        printf("Preis: %.2f CHF\n", price);
        productPrice = price;
        sleep(2);
    }

    int paymentOptions() //Zeig die Auswahl der Zahlungsmethoden an **********
    {
        title();
        printf("Bitte waehlen Sie ihre Zahlungsmethode:\n");
        printf("[ 1 ] Barbezahlung\n");
        printf("[ 2 ] Bezahlung mit Karte\n");
        printf("[ 3 ] Bezahlung mit Twint\n");
        scanf("%d", &intInput);
        return 0;
    }


    int paymentCash() //Führt die Bezahlung mit Bargeld aus **********
    {
        title();
        while (price > 0)
        {
        title();
        printf("Bitte werfen sie den Betrag ein\n");
        fontRed();
        printf("CHF %.2f\n", price);
        fontGreen();
        printf("CHF ");
        scanf("%f", &cashInput);
        cashInputInt = (int)(cashInput * 100);
        switch (cashInputInt) //Nur gültige echte Münzen werden akzeptiert
        {
        case 5:
            {cashInput = 0.05;
            break;}
        case 10:
            {cashInput = 0.1;
            break;}
        case 20:
            {cashInput = 0.2;
            break;}
        case 50:
            {cashInput = 0.5;
            break;}
        case 100:
            {cashInput = 1;
            break; }
        case 200:
            {cashInput = 2;
            break;}
        case 500:
            {cashInput = 5;
            break;}
        default:
            {cashInput = 0;
            invalidInput();
            break;}
        }
        if ((price - cashInput) > 0)
        {
        price = (float)price - (float)cashInput;
        i = 1;
        }
        if ((price - cashInput) < 0 && i == 0) //Rückgeld wird erstattet bei übertreffen des Preises
        {
        price = cashInput - price;
        title();
        printf("%.2f CHF werden ausgegeben...\n", price);
        sleep(2);
        title();
        fontGreen();
        printf("Verarbeitung OK\n");
        sleep(2);
        price = 0;
        }
        i = 0;
        }
        cashInput = 0;
        price = 0;
        return 0;
    }

    int paymentCard() //Führt die Bezahlung mit Karte aus **********
    {
        title();
        printf("Bitte Karte einlegen (Taste druecken)\n");
        printf("CHF %g\n", price);
        sleep(1);
        system("pause > nul");
        title();
        printf("%.2f CHF werden bezahlt...\n", price);
        sleep(2);
        title();
        fontGreen();
        printf("Verarbeitung OK\n");
        sleep(2);
        price = 0;
        return 0;
    }

    int paymentTwint() //Führt die Bezahlung mit Twint aus **********
    {
        twintCode = 12345;
        title();
        printf("Bitte %d in Ihrer Twint App eingeben (Taste druecken)\n", twintCode);
        printf("CHF %.2f\n", price);
        system("pause > nul");
        title();
        printf("%.2f CHF werden bezahlt...\n", price);
        sleep(2);
        title();
        fontGreen();
        printf("Verarbeitung OK\n");
        sleep(2);
        price = 0;
        return 0;
    }

    int productOutput() //Gibt das Produkt aus und bestätigt die Bezahlung **********
    {
        title();
        printf("Produkt wird Ausgegeben\n");
        sleep(2);
        title();
        fontGreen();
        printf("Vielen Dank!\n");
        printf("Bezahlt: CHF %.2f\n", productPrice);
        sleep(4);
    }

//****************************************
//Main

int main() //Programmablauf
{
    restock(); //Produkte anzeigen
    do
    { //********************

        error = 0;
        
        title();
        
        productOptions();  //Produktauswahl anzeigen
        if (error == 1) {continue;} //Fehler prüfen und Programm neu starten
        
        if (stock[stockRequestY][stockRequestX] >= 1) //Lagerbestand überprüfen
        {
        
        paymentOptions(); //Zahlungsmethodenauswahl anzeigen
        if (error == 1) {continue;} //Fehler prüfen und Programm neu starten

        switch (intInput)
        {
        case 1: {paymentCash(); break;} //Startet die Bezahlung mit Bargeld
        case 2: {paymentCard(); break;} //Startet die Bezahlung mit Karte
        case 3: {paymentTwint(); break;}  //Startet die Bezahlung mit Twint
        }
        if (error == 1) {continue;} //Fehler prüfen und Programm neu starten
        
        productOutput(); //Programmausgabe und Kaufbestätigung

        stock[stockRequestY][stockRequestX]--; //Lagerbestand aktualisieren
        }
        
        else {stockError();} //Fehlermeldung für ausverkaufte Produkte

    } //********************
    while (1); //Ständige wiederholung
    return 0;
}

//****************************************